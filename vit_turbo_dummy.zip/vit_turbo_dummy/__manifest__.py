{
	"name": "Create Dummy Account Move (Journal ENtries) and Partner in Turbo Speed",
	"version": "1.0",
	"depends": [
		"account","accounting_pdf_reports","stock","purchase","sale"
	],
	'images': ['static/description/images/main_screenshot.png'],
	"author": "vitraining.com",
	"website": "vitraining.com", 
    'category': 'Accounting',
    'price':'300',
    'currency': 'USD',
	"category": "Accounting",
	"summary": "Create Dummy Account Move (Journal ENtries) and Partner in Turbo Speed",
	"description": """\


""",
	"data": [
		"wizard/dummy_account_move.xml",


	],
	"application": True,
	"installable": True,
	"auto_install": False,
}