{
	"name": "Export Account Move (Journal Entries) to CSV in Turbo Speed",
	"version": "1.0",
	"depends": [
		"account","accounting_pdf_reports"
	],
	'images': ['static/description/images/main_screenshot.png'],
	"author": "vitraining.com",
	"website": "vitraining.com", 
    'category': 'Accounting',
    'price':'300',
    'currency': 'USD',
	"category": "Accounting",
	"summary": "Export Account Move (Journal ENtries) to CSV in Turbo Speed",
	"description": """\


""",
	"data": [
		"wizard/account_move.xml",
		"view/account_move.xml",


	],
	"application": True,
	"installable": True,
	"auto_install": False,
}